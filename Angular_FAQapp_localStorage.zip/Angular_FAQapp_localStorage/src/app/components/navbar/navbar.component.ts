import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'navbar',
    templateUrl: './navbar.component.html',
    styleUrls: ['./navbar.component.css'],
    inputs: ['getTitle','getAuthor']
})

export class NavbarComponent implements OnInit {
    getTitle:string;
    getAuthor:string;

    constructor(){
        
    }

    ngOnInit() {

    }
}