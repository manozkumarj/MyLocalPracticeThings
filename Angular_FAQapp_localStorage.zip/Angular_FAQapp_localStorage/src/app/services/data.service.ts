import { Injectable } from "@angular/core";
import { Question } from '../models/Question'

@Injectable()
export class DataService{

    questions:Question[];

    constructor(){

    /*
      this.questions = [
        {
          text:"What is your name",
          answer: "Manoz Kumar",
          hide: true
        },
        {
          text:"What is your name",
          answer: "Mahesh Kumar",
          hide: true
        },
        {
          text:"What is your name",
          answer: "Rammy Kumar",
          hide: true
        },
        {
          text:"What is your name",
          answer: "Kranthi Kumar",
          hide: true
        }
      ]
    */

    }

    getQuestions(){
      let getQuestions = localStorage.getItem('questions');
        if(getQuestions === null){
          this.questions = [];
        }else{
          this.questions = JSON.parse(localStorage.getItem('questions'));
        }
        return this.questions;
    }


    // Adding new question func
    addQuestion(question:Question){
      this.questions.unshift(question);

      let questions;
      let getQuestions = localStorage.getItem('questions');
        if(getQuestions === null){
          questions = [];
        }else{
          questions = JSON.parse(localStorage.getItem('questions'));

        }

        questions.unshift(question);
        localStorage.setItem('questions', JSON.stringify(questions));

    }

    removeQuestion(question:Question){
      // console.log(question);
      for(let i=0; i < this.questions.length; i++){
          if(question == this.questions[i]){
            this.questions.splice(i,1);
            localStorage.setItem('questions', JSON.stringify(this.questions));
          }
      }
    }

}